# Third-Party Notices

The embedded image definition installs third-party software from a pinned Flox
base image, Coop's locked core Flox environment, and a pinned Nixpkgs revision
for configured tools. Those packages remain subject to their own licenses,
notices, and terms; coop's Apache-2.0 license does not replace them.

The public beta builds this image locally and does not publish or redistribute
the resulting image. Before redistributing a locally built image, review the
licenses and terms for its complete package closure.
Repository and global `[tools].packages` additions expand that closure and must
be reviewed as well. Trusted `[[tools.github_release]]` declarations also copy
third-party executables into the local image. Their upstream licenses, notices,
and redistribution terms apply even though Coop verifies their release-asset
digests.

In particular, the image definition installs Claude Code, whose published
license states that use is subject to Anthropic's terms and does not provide an
express general redistribution grant. Do not redistribute that binary as part
of a coop image without confirming permission. Codex is published under
Apache-2.0 and OpenCode under MIT; their license and notice obligations still
apply to redistributed copies.

## Kata test schema

`internal/taskstore/testdata/kata-v0.19.0-schema.sql` is the unmodified SQLite
schema from [Kata v0.19.0](https://github.com/kenn-io/kata/blob/v0.19.0/internal/db/sqlitestore/schema.sql).
It is used only by provider regression tests. Copyright (c) 2026 Wes McKinney;
licensed under MIT. The full notice is retained beside it in
`internal/taskstore/testdata/kata-v0.19.0-LICENSE.txt`.

## Master SQLite dependency notices

The Coop master embeds modernc.org/sqlite v1.60.1 and the dependencies below. These upstream notices accompany the existing release archive. SQLite itself is in the public domain.

### modernc.org/sqlite v1.60.1 / LICENSE

    Copyright (c) 2017 The Sqlite Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

    3. Neither the name of the copyright holder nor the names of its contributors
    may be used to endorse or promote products derived from this software without
    specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### modernc.org/sqlite v1.60.1 / LICENSE-3RD-PARTY.md

    # Third-Party Licenses

    `modernc.org/sqlite` is BSD-3-Clause; that license is in [LICENSE](LICENSE) and it is
    not repeated here. This file accounts for everything else -- every other body of code,
    of any origin, that reaches you through this repository.

    The list is **transitively flattened**. It is not the direct dependencies of
    `go.mod`: it is the whole module graph, `go list -m all`, plus the third-party C that
    was transpiled into Go and committed here, plus the upstream notices that dependencies
    carry in turn -- musl libc, for one, reaches you through `modernc.org/libc` and appears
    below on its own account. Each component is classified by what it actually does to a
    program that imports this driver, because "a dependency" and "code in your binary"
    are not the same question:

    - [1. Components linked into your program](#1-components-linked-into-your-program)
    - [2. Components used only by the test suite](#2-components-used-only-by-the-test-suite)
    - [3. Components in the module graph, not compiled into anything](#3-components-in-the-module-graph-not-compiled-into-anything)
    - [4. Third-party material in the repository, outside any build](#4-third-party-material-in-the-repository-outside-any-build)
    - [Appendix A: license texts](#appendix-a-license-texts)
    - [Appendix B: inherited third-party notices](#appendix-b-inherited-third-party-notices)

    Every license text referenced by the tables is reproduced in full in Appendix A. Where
    several components share one text, it appears once, with every copyright notice that
    came with it merged in place -- nothing is summarized, truncated or linked away.

    <!--
    Generated by licensegen. Do not edit by hand: run `make licenses`.
    The output is deterministic and carries no timestamp, so a diff here means the tree's
    third-party content really changed.
    -->

    ## 1. Components linked into your program

    Everything below ends up in a binary that imports `modernc.org/sqlite`. This is the
    section that matters when you redistribute software built on this driver: the notices
    and license texts it points at are the ones you have to carry with you.

    | Component | Version | License | Reached via | Text |
    | --- | --- | --- | --- | --- |
    | [github.com/dustin/go-humanize](https://pkg.go.dev/github.com/dustin/go-humanize) | v1.0.1 | MIT | modernc.org/libc, `go.mod` | [L1](#L1) |
    | [github.com/google/uuid](https://pkg.go.dev/github.com/google/uuid) | v1.6.0 | BSD-3-Clause | modernc.org/libc, `go.mod` | [L2](#L2) |
    | [github.com/remyoudompheng/bigfft](https://pkg.go.dev/github.com/remyoudompheng/bigfft) | v0.0.0-20230129092748-24d4a6f8daec | BSD-3-Clause | modernc.org/fileutil, modernc.org/libc, modernc.org/mathutil, modernc.org/memory, `go.mod` | [L2](#L2) |
    | [Go](https://github.com/golang/go) | -- | BSD-3-Clause | modernc.org/libc | [N1](#N1) |
    | [go-netdb](https://github.com/dominikh/go-netdb) | -- | MIT | modernc.org/libc | [N1](#N1) |
    | [golang.org/x/sys](https://pkg.go.dev/golang.org/x/sys) | v0.48.0 | BSD-3-Clause | github.com/google/pprof, github.com/mattn/go-isatty, modernc.org/libc, modernc.org/memory, `go.mod` | [L3](#L3) |
    | [modernc.org/libc](https://pkg.go.dev/modernc.org/libc) | v1.77.1 | BSD-3-Clause | `go.mod` | [L4](#L4) |
    | [modernc.org/mathutil](https://pkg.go.dev/modernc.org/mathutil) | v1.7.1 | BSD-3-Clause | modernc.org/fileutil, modernc.org/libc, modernc.org/memory, `go.mod` | [L4](#L4) |
    | [modernc.org/memory](https://pkg.go.dev/modernc.org/memory) | v1.12.1 | BSD-3-Clause, attribution reference | modernc.org/libc, `go.mod` | [L4](#L4), [L2](#L2), [L5](#L5), [L6](#L6) |
    | [musl libc](https://musl.libc.org/) | -- | MIT | modernc.org/libc | [N1](#N1) |
    | [NixOS/nixpkgs](https://github.com/NixOS/nixpkgs) | -- | MIT | modernc.org/libc | [N1](#N1) |
    | [SQLite](https://sqlite.org/) | 3.53.4 | public domain | transpiled into `lib/` | [L7](#L7) |
    | [sqlite-vec](https://github.com/asg017/sqlite-vec) | v0.1.9 | MIT | transpiled into `vec/` | [L8](#L8) |
    | [SQLite `test_demovfs.c`](https://www.sqlite.org/src/doc/trunk/src/test_demovfs.c) | -- | public domain | `vfs/c/vfs.c`, transpiled into `vfs/` | [L7](#L7) |

    - **SQLite** -- The SQLite C amalgamation, translated to Go by `modernc.org/ccgo`. Local copy of the upstream dedication: `LICENSE-SQLITE`.
    - **sqlite-vec** -- Vector-search extension, linked only when `modernc.org/sqlite/vec` is imported. Local copy: `LICENSE-SQLITE_VEC`.
    - **SQLite `test_demovfs.c`** -- Starting point of the Go-fs VFS bridge, linked only when `modernc.org/sqlite/vfs` is imported. Carries SQLite's own copyright disclaimer.

    ## 2. Components used only by the test suite

    Compiled into this repository's own tests only. It is not part of the library and does
    not reach a program that imports `modernc.org/sqlite`.

    | Component | Version | License | Reached via | Text |
    | --- | --- | --- | --- | --- |
    | [github.com/google/pprof](https://pkg.go.dev/github.com/google/pprof) | v0.0.0-20260802141513-ef3492d7dac3 | Apache-2.0, BSD-3-Clause | `go.mod` | [L9](#L9), [L10](#L10) |
    | [modernc.org/fileutil](https://pkg.go.dev/modernc.org/fileutil) | v1.4.0 | BSD-3-Clause | modernc.org/libc, `go.mod` | [L4](#L4), [L11](#L11) |

    ## 3. Components in the module graph, not compiled into anything

    Reachable in the module graph -- `go list -m all` reports them, and the Go module proxy
    will fetch them -- but no package of theirs is compiled into the library or into its
    tests. They are listed for completeness, because tools that read `go.sum` or an SBOM
    generated from the module graph will report them. Note in particular that the only
    copyleft-adjacent license anywhere in this project, MPL-2.0, appears here and only here.
    `modernc.org/ccgo` and `modernc.org/cc` are in this section because `modernc.org/libc`
    requires them; they are separately the transpilers that produced the Go code in `lib/`
    and `vec/`, but that happens in the sibling `libsqlite3` repository, not in any build of
    this one.

    | Component | Version | License | Reached via | Text |
    | --- | --- | --- | --- | --- |
    | [github.com/chzyer/readline](https://pkg.go.dev/github.com/chzyer/readline) | v1.5.1 | MIT | github.com/google/pprof | [L12](#L12) |
    | [github.com/hashicorp/golang-lru/v2](https://pkg.go.dev/github.com/hashicorp/golang-lru/v2) | v2.0.7 | MPL-2.0, BSD-3-Clause | modernc.org/libc | [L13](#L13), [L14](#L14) |
    | [github.com/ianlancetaylor/demangle](https://pkg.go.dev/github.com/ianlancetaylor/demangle) | v0.0.0-20250417193237-f615e6bd150b | BSD-3-Clause | github.com/google/pprof | [L2](#L2) |
    | [github.com/mattn/go-isatty](https://pkg.go.dev/github.com/mattn/go-isatty) | v0.0.24 | MIT | modernc.org/libc, `go.mod` | [L15](#L15) |
    | [github.com/ncruces/go-strftime](https://pkg.go.dev/github.com/ncruces/go-strftime) | v1.0.0 | MIT | modernc.org/libc, `go.mod` | [L8](#L8) |
    | [golang.org/x/mod](https://pkg.go.dev/golang.org/x/mod) | v0.41.0 | BSD-3-Clause | modernc.org/libc | [L3](#L3) |
    | [golang.org/x/sync](https://pkg.go.dev/golang.org/x/sync) | v0.23.0 | BSD-3-Clause | modernc.org/libc | [L3](#L3) |
    | [golang.org/x/tools](https://pkg.go.dev/golang.org/x/tools) | v0.50.0 | BSD-3-Clause | modernc.org/libc | [L3](#L3) |
    | [modernc.org/cc/v4](https://pkg.go.dev/modernc.org/cc/v4) | v4.29.7 | BSD-3-Clause | modernc.org/libc | [L4](#L4) |
    | [modernc.org/ccgo/v4](https://pkg.go.dev/modernc.org/ccgo/v4) | v4.36.1 | BSD-3-Clause | modernc.org/libc | [L4](#L4) |
    | [modernc.org/gc/v2](https://pkg.go.dev/modernc.org/gc/v2) | v2.6.5 | BSD-3-Clause | modernc.org/libc | [L16](#L16) |
    | [modernc.org/gc/v3](https://pkg.go.dev/modernc.org/gc/v3) | v3.1.5 | BSD-3-Clause | modernc.org/libc | [L16](#L16) |
    | [modernc.org/goabi0](https://pkg.go.dev/modernc.org/goabi0) | v0.2.0 | BSD-3-Clause | modernc.org/libc | [L17](#L17) |
    | [modernc.org/opt](https://pkg.go.dev/modernc.org/opt) | v0.2.0 | BSD-3-Clause | modernc.org/libc | [L4](#L4) |
    | [modernc.org/sortutil](https://pkg.go.dev/modernc.org/sortutil) | v1.2.1 | BSD-3-Clause | modernc.org/libc | [L4](#L4) |
    | [modernc.org/strutil](https://pkg.go.dev/modernc.org/strutil) | v1.2.1 | BSD-3-Clause | modernc.org/libc | [L4](#L4) |
    | [modernc.org/token](https://pkg.go.dev/modernc.org/token) | v1.1.0 | BSD-3-Clause | modernc.org/libc | [L2](#L2) |

    ## 4. Third-party material in the repository, outside any build

    Present in a clone or a source tarball of this repository, compiled into nothing. Listed
    so that a redistribution of the source tree is covered as well as a redistribution of a
    binary.

    | Material | Location | Origin | License | Text |
    | --- | --- | --- | --- | --- |
    | SQLite TCL test suite | `testdata/tcl/`, `testdata/overlay/`, `testdata/mptest.c` | [SQLite](https://sqlite.org/) | public domain | [L7](#L7) |
    | Sponsor logos and word marks | `sponsors/` | the respective sponsors | -- | -- |

    The sponsor logos and word marks in `sponsors/` are the trademarks of their owners. They
    are reproduced to acknowledge sponsorship, are not licensed under this project's
    license, and confer no right to use those marks.

    `vendor_libs/` is a second, self-contained Go module holding the regeneration tool
    invoked by `make vendor`. Its own dependencies are a subset of the modules already
    listed above.

    ## Appendix A: license texts

    Verbatim. The only editing is the merging of copyright notices where one text is shared
    by several components; where a component's text is unique, it is byte-for-byte the file
    shipped upstream.

    <a id="L1"></a>

    ### L1: MIT

    Applies to:

    - github.com/dustin/go-humanize -- Copyright (c) 2005-2008  Dustin Sallings <dustin@spy.net>

    ```text
    Copyright (c) 2005-2008  Dustin Sallings <dustin@spy.net>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

    <http://www.opensource.org/licenses/mit-license.php>
    ```

    <a id="L2"></a>

    ### L2: BSD-3-Clause

    Applies to:

    - github.com/google/uuid -- Copyright (c) 2009,2014 Google Inc. All rights reserved.
    - github.com/ianlancetaylor/demangle -- Copyright (c) 2015 The Go Authors. All rights reserved.
    - github.com/remyoudompheng/bigfft -- Copyright (c) 2012 The Go Authors. All rights reserved.
    - modernc.org/memory (`LICENSE-GO`) -- Copyright (c) 2009 The Go Authors. All rights reserved.
    - modernc.org/token -- Copyright (c) 2009 The Go Authors. All rights reserved.

    ```text
    Copyright (c) 2009,2014 Google Inc. All rights reserved.
    Copyright (c) 2015 The Go Authors. All rights reserved.
    Copyright (c) 2012 The Go Authors. All rights reserved.
    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L3"></a>

    ### L3: BSD-3-Clause

    Applies to:

    - golang.org/x/mod -- Copyright 2009 The Go Authors.
    - golang.org/x/sync -- Copyright 2009 The Go Authors.
    - golang.org/x/sys -- Copyright 2009 The Go Authors.
    - golang.org/x/tools -- Copyright 2009 The Go Authors.

    ```text
    Copyright 2009 The Go Authors.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google LLC nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L4"></a>

    ### L4: BSD-3-Clause

    Applies to:

    - modernc.org/cc/v4 -- Copyright (c) 2014 The CC Authors. All rights reserved.
    - modernc.org/ccgo/v4 -- Copyright (c) 2017 The CCGO Authors. All rights reserved.
    - modernc.org/fileutil -- Copyright (c) 2014 The fileutil Authors. All rights reserved.
    - modernc.org/libc -- Copyright (c) 2017 The Libc Authors. All rights reserved.
    - modernc.org/mathutil -- Copyright (c) 2014 The mathutil Authors. All rights reserved.
    - modernc.org/mathutil (`mersenne/LICENSE`) -- Copyright (c) 2014 The mersenne Authors. All rights reserved.
    - modernc.org/memory -- Copyright (c) 2017 The Memory Authors. All rights reserved.
    - modernc.org/opt -- Copyright (c) 2019 The Opt Authors. All rights reserved.
    - modernc.org/sortutil -- Copyright (c) 2014 The sortutil Authors. All rights reserved.
    - modernc.org/strutil -- Copyright (c) 2014 The strutil Authors. All rights reserved.

    ```text
    Copyright (c) 2014 The CC Authors. All rights reserved.
    Copyright (c) 2017 The CCGO Authors. All rights reserved.
    Copyright (c) 2014 The fileutil Authors. All rights reserved.
    Copyright (c) 2017 The Libc Authors. All rights reserved.
    Copyright (c) 2014 The mathutil Authors. All rights reserved.
    Copyright (c) 2014 The mersenne Authors. All rights reserved.
    Copyright (c) 2017 The Memory Authors. All rights reserved.
    Copyright (c) 2019 The Opt Authors. All rights reserved.
    Copyright (c) 2014 The sortutil Authors. All rights reserved.
    Copyright (c) 2014 The strutil Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the names of the authors nor the names of the
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L5"></a>

    ### L5: attribution reference

    Applies to:

    - modernc.org/memory (`LICENSE-LOGO`)

    ```text
    https://commons.wikimedia.org/wiki/File:Memory_infra_logo.png
    ```

    <a id="L6"></a>

    ### L6: BSD-3-Clause

    Applies to:

    - modernc.org/memory (`LICENSE-MMAP-GO`) -- Copyright (c) 2011, Evan Shaw <edsrzf@gmail.com> All rights reserved.

    ```text
    Copyright (c) 2011, Evan Shaw <edsrzf@gmail.com>
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
        * Redistributions of source code must retain the above copyright
          notice, this list of conditions and the following disclaimer.
        * Redistributions in binary form must reproduce the above copyright
          notice, this list of conditions and the following disclaimer in the
          documentation and/or other materials provided with the distribution.
        * Neither the name of the copyright holder nor the
          names of its contributors may be used to endorse or promote products
          derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L7"></a>

    ### L7: public domain

    Applies to:

    - SQLite 3.53.4 (`LICENSE-SQLITE`)
    - SQLite `test_demovfs.c`
    - SQLite test suite (`testdata/`)

    ```text
    SQLite Is Public Domain

    All of the code and documentation in SQLite has been dedicated to the public
    domain by the authors. All code authors, and representatives of the companies
    they work for, have signed affidavits dedicating their contributions to the
    public domain and originals of those signed affidavits are stored in a firesafe
    at the main offices of Hwaci. Anyone is free to copy, modify, publish, use,
    compile, sell, or distribute the original SQLite code, either in source code
    form or as a compiled binary, for any purpose, commercial or non-commercial,
    and by any means.

    The previous paragraph applies to the deliverable code and documentation in
    SQLite - those parts of the SQLite library that you actually bundle and ship
    with a larger application. Some scripts used as part of the build process (for
    example the "configure" scripts generated by autoconf) might fall under other
    open-source licenses. Nothing from these build scripts ever reaches the final
    deliverable SQLite library, however, and so the licenses associated with those
    scripts should not be a factor in assessing your rights to copy and use the
    SQLite library.

    All of the deliverable code in SQLite has been written from scratch. No code
    has been taken from other projects or from the open internet. Every line of
    code can be traced back to its original author, and all of those authors have
    public domain dedications on file. So the SQLite code base is clean and is
    uncontaminated with licensed code from other projects.
    ```

    <a id="L8"></a>

    ### L8: MIT

    Applies to:

    - github.com/ncruces/go-strftime -- Copyright (c) 2022 Nuno Cruces
    - sqlite-vec v0.1.9 (`LICENSE-SQLITE_VEC`) -- Copyright (c) 2024 Alex Garcia

    ```text
    MIT License

    Copyright (c) 2022 Nuno Cruces
    Copyright (c) 2024 Alex Garcia

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    ```

    <a id="L9"></a>

    ### L9: Apache-2.0

    Applies to:

    - github.com/google/pprof --    Copyright [yyyy] [name of copyright owner]

    ```text
                                     Apache License
                               Version 2.0, January 2004
                            http://www.apache.org/licenses/

       TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

       1. Definitions.

          "License" shall mean the terms and conditions for use, reproduction,
          and distribution as defined by Sections 1 through 9 of this document.

          "Licensor" shall mean the copyright owner or entity authorized by
          the copyright owner that is granting the License.

          "Legal Entity" shall mean the union of the acting entity and all
          other entities that control, are controlled by, or are under common
          control with that entity. For the purposes of this definition,
          "control" means (i) the power, direct or indirect, to cause the
          direction or management of such entity, whether by contract or
          otherwise, or (ii) ownership of fifty percent (50%) or more of the
          outstanding shares, or (iii) beneficial ownership of such entity.

          "You" (or "Your") shall mean an individual or Legal Entity
          exercising permissions granted by this License.

          "Source" form shall mean the preferred form for making modifications,
          including but not limited to software source code, documentation
          source, and configuration files.

          "Object" form shall mean any form resulting from mechanical
          transformation or translation of a Source form, including but
          not limited to compiled object code, generated documentation,
          and conversions to other media types.

          "Work" shall mean the work of authorship, whether in Source or
          Object form, made available under the License, as indicated by a
          copyright notice that is included in or attached to the work
          (an example is provided in the Appendix below).

          "Derivative Works" shall mean any work, whether in Source or Object
          form, that is based on (or derived from) the Work and for which the
          editorial revisions, annotations, elaborations, or other modifications
          represent, as a whole, an original work of authorship. For the purposes
          of this License, Derivative Works shall not include works that remain
          separable from, or merely link (or bind by name) to the interfaces of,
          the Work and Derivative Works thereof.

          "Contribution" shall mean any work of authorship, including
          the original version of the Work and any modifications or additions
          to that Work or Derivative Works thereof, that is intentionally
          submitted to Licensor for inclusion in the Work by the copyright owner
          or by an individual or Legal Entity authorized to submit on behalf of
          the copyright owner. For the purposes of this definition, "submitted"
          means any form of electronic, verbal, or written communication sent
          to the Licensor or its representatives, including but not limited to
          communication on electronic mailing lists, source code control systems,
          and issue tracking systems that are managed by, or on behalf of, the
          Licensor for the purpose of discussing and improving the Work, but
          excluding communication that is conspicuously marked or otherwise
          designated in writing by the copyright owner as "Not a Contribution."

          "Contributor" shall mean Licensor and any individual or Legal Entity
          on behalf of whom a Contribution has been received by Licensor and
          subsequently incorporated within the Work.

       2. Grant of Copyright License. Subject to the terms and conditions of
          this License, each Contributor hereby grants to You a perpetual,
          worldwide, non-exclusive, no-charge, royalty-free, irrevocable
          copyright license to reproduce, prepare Derivative Works of,
          publicly display, publicly perform, sublicense, and distribute the
          Work and such Derivative Works in Source or Object form.

       3. Grant of Patent License. Subject to the terms and conditions of
          this License, each Contributor hereby grants to You a perpetual,
          worldwide, non-exclusive, no-charge, royalty-free, irrevocable
          (except as stated in this section) patent license to make, have made,
          use, offer to sell, sell, import, and otherwise transfer the Work,
          where such license applies only to those patent claims licensable
          by such Contributor that are necessarily infringed by their
          Contribution(s) alone or by combination of their Contribution(s)
          with the Work to which such Contribution(s) was submitted. If You
          institute patent litigation against any entity (including a
          cross-claim or counterclaim in a lawsuit) alleging that the Work
          or a Contribution incorporated within the Work constitutes direct
          or contributory patent infringement, then any patent licenses
          granted to You under this License for that Work shall terminate
          as of the date such litigation is filed.

       4. Redistribution. You may reproduce and distribute copies of the
          Work or Derivative Works thereof in any medium, with or without
          modifications, and in Source or Object form, provided that You
          meet the following conditions:

          (a) You must give any other recipients of the Work or
              Derivative Works a copy of this License; and

          (b) You must cause any modified files to carry prominent notices
              stating that You changed the files; and

          (c) You must retain, in the Source form of any Derivative Works
              that You distribute, all copyright, patent, trademark, and
              attribution notices from the Source form of the Work,
              excluding those notices that do not pertain to any part of
              the Derivative Works; and

          (d) If the Work includes a "NOTICE" text file as part of its
              distribution, then any Derivative Works that You distribute must
              include a readable copy of the attribution notices contained
              within such NOTICE file, excluding those notices that do not
              pertain to any part of the Derivative Works, in at least one
              of the following places: within a NOTICE text file distributed
              as part of the Derivative Works; within the Source form or
              documentation, if provided along with the Derivative Works; or,
              within a display generated by the Derivative Works, if and
              wherever such third-party notices normally appear. The contents
              of the NOTICE file are for informational purposes only and
              do not modify the License. You may add Your own attribution
              notices within Derivative Works that You distribute, alongside
              or as an addendum to the NOTICE text from the Work, provided
              that such additional attribution notices cannot be construed
              as modifying the License.

          You may add Your own copyright statement to Your modifications and
          may provide additional or different license terms and conditions
          for use, reproduction, or distribution of Your modifications, or
          for any such Derivative Works as a whole, provided Your use,
          reproduction, and distribution of the Work otherwise complies with
          the conditions stated in this License.

       5. Submission of Contributions. Unless You explicitly state otherwise,
          any Contribution intentionally submitted for inclusion in the Work
          by You to the Licensor shall be under the terms and conditions of
          this License, without any additional terms or conditions.
          Notwithstanding the above, nothing herein shall supersede or modify
          the terms of any separate license agreement you may have executed
          with Licensor regarding such Contributions.

       6. Trademarks. This License does not grant permission to use the trade
          names, trademarks, service marks, or product names of the Licensor,
          except as required for reasonable and customary use in describing the
          origin of the Work and reproducing the content of the NOTICE file.

       7. Disclaimer of Warranty. Unless required by applicable law or
          agreed to in writing, Licensor provides the Work (and each
          Contributor provides its Contributions) on an "AS IS" BASIS,
          WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
          implied, including, without limitation, any warranties or conditions
          of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
          PARTICULAR PURPOSE. You are solely responsible for determining the
          appropriateness of using or redistributing the Work and assume any
          risks associated with Your exercise of permissions under this License.

       8. Limitation of Liability. In no event and under no legal theory,
          whether in tort (including negligence), contract, or otherwise,
          unless required by applicable law (such as deliberate and grossly
          negligent acts) or agreed to in writing, shall any Contributor be
          liable to You for damages, including any direct, indirect, special,
          incidental, or consequential damages of any character arising as a
          result of this License or out of the use or inability to use the
          Work (including but not limited to damages for loss of goodwill,
          work stoppage, computer failure or malfunction, or any and all
          other commercial damages or losses), even if such Contributor
          has been advised of the possibility of such damages.

       9. Accepting Warranty or Additional Liability. While redistributing
          the Work or Derivative Works thereof, You may choose to offer,
          and charge a fee for, acceptance of support, warranty, indemnity,
          or other liability obligations and/or rights consistent with this
          License. However, in accepting such obligations, You may act only
          on Your own behalf and on Your sole responsibility, not on behalf
          of any other Contributor, and only if You agree to indemnify,
          defend, and hold each Contributor harmless for any liability
          incurred by, or claims asserted against, such Contributor by reason
          of your accepting any such warranty or additional liability.

       END OF TERMS AND CONDITIONS

       APPENDIX: How to apply the Apache License to your work.

          To apply the Apache License to your work, attach the following
          boilerplate notice, with the fields enclosed by brackets "[]"
          replaced with your own identifying information. (Don't include
          the brackets!)  The text should be enclosed in the appropriate
          comment syntax for the file format. We also recommend that a
          file or class name and description of purpose be included on the
          same "printed page" as the copyright notice for easier
          identification within third-party archives.

       Copyright [yyyy] [name of copyright owner]

       Licensed under the Apache License, Version 2.0 (the "License");
       you may not use this file except in compliance with the License.
       You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing, software
       distributed under the License is distributed on an "AS IS" BASIS,
       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       See the License for the specific language governing permissions and
       limitations under the License.
    ```

    <a id="L10"></a>

    ### L10: BSD-3-Clause

    Applies to:

    - github.com/google/pprof (`third_party/svgpan/LICENSE`) -- Copyright 2009-2017 Andrea Leofreddi <a.leofreddi@vleo.net>. All rights reserved.

    ```text
    Copyright 2009-2017 Andrea Leofreddi <a.leofreddi@vleo.net>. All rights reserved.

    Redistribution and use in source and binary forms, with or without modification, are
    permitted provided that the following conditions are met:

       1. Redistributions of source code must retain the above copyright
          notice, this list of conditions and the following disclaimer.
       2. Redistributions in binary form must reproduce the above copyright
          notice, this list of conditions and the following disclaimer in the
          documentation and/or other materials provided with the distribution.
       3. Neither the name of the copyright holder nor the names of its
          contributors may be used to endorse or promote products derived from
          this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS
    OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL COPYRIGHT HOLDERS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

    The views and conclusions contained in the software and documentation are those of the
    authors and should not be interpreted as representing official policies, either expressed
    or implied, of Andrea Leofreddi.
    ```

    <a id="L11"></a>

    ### L11: BSD-3-Clause

    Applies to:

    - modernc.org/fileutil (`falloc/LICENSE`) -- Copyright (c) 2011 CZ.NIC z.s.p.o. All rights reserved.
    - modernc.org/fileutil (`hdb/LICENSE`) -- Copyright (c) 2011 CZ.NIC z.s.p.o. All rights reserved.
    - modernc.org/fileutil (`storage/LICENSE`) -- Copyright (c) 2011 CZ.NIC z.s.p.o. All rights reserved.

    ```text
    Copyright (c) 2011 CZ.NIC z.s.p.o. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of CZ.NIC nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L12"></a>

    ### L12: MIT

    Applies to:

    - github.com/chzyer/readline -- Copyright (c) 2015 Chzyer

    ```text
    The MIT License (MIT)

    Copyright (c) 2015 Chzyer

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    ```

    <a id="L13"></a>

    ### L13: MPL-2.0

    Applies to:

    - github.com/hashicorp/golang-lru/v2 -- Copyright (c) 2014 HashiCorp, Inc.

    ```text
    Copyright (c) 2014 HashiCorp, Inc.

    Mozilla Public License, version 2.0

    1. Definitions

    1.1. "Contributor"

         means each individual or legal entity that creates, contributes to the
         creation of, or owns Covered Software.

    1.2. "Contributor Version"

         means the combination of the Contributions of others (if any) used by a
         Contributor and that particular Contributor's Contribution.

    1.3. "Contribution"

         means Covered Software of a particular Contributor.

    1.4. "Covered Software"

         means Source Code Form to which the initial Contributor has attached the
         notice in Exhibit A, the Executable Form of such Source Code Form, and
         Modifications of such Source Code Form, in each case including portions
         thereof.

    1.5. "Incompatible With Secondary Licenses"
         means

         a. that the initial Contributor has attached the notice described in
            Exhibit B to the Covered Software; or

         b. that the Covered Software was made available under the terms of
            version 1.1 or earlier of the License, but not also under the terms of
            a Secondary License.

    1.6. "Executable Form"

         means any form of the work other than Source Code Form.

    1.7. "Larger Work"

         means a work that combines Covered Software with other material, in a
         separate file or files, that is not Covered Software.

    1.8. "License"

         means this document.

    1.9. "Licensable"

         means having the right to grant, to the maximum extent possible, whether
         at the time of the initial grant or subsequently, any and all of the
         rights conveyed by this License.

    1.10. "Modifications"

         means any of the following:

         a. any file in Source Code Form that results from an addition to,
            deletion from, or modification of the contents of Covered Software; or

         b. any new file in Source Code Form that contains any Covered Software.

    1.11. "Patent Claims" of a Contributor

          means any patent claim(s), including without limitation, method,
          process, and apparatus claims, in any patent Licensable by such
          Contributor that would be infringed, but for the grant of the License,
          by the making, using, selling, offering for sale, having made, import,
          or transfer of either its Contributions or its Contributor Version.

    1.12. "Secondary License"

          means either the GNU General Public License, Version 2.0, the GNU Lesser
          General Public License, Version 2.1, the GNU Affero General Public
          License, Version 3.0, or any later versions of those licenses.

    1.13. "Source Code Form"

          means the form of the work preferred for making modifications.

    1.14. "You" (or "Your")

          means an individual or a legal entity exercising rights under this
          License. For legal entities, "You" includes any entity that controls, is
          controlled by, or is under common control with You. For purposes of this
          definition, "control" means (a) the power, direct or indirect, to cause
          the direction or management of such entity, whether by contract or
          otherwise, or (b) ownership of more than fifty percent (50%) of the
          outstanding shares or beneficial ownership of such entity.


    2. License Grants and Conditions

    2.1. Grants

         Each Contributor hereby grants You a world-wide, royalty-free,
         non-exclusive license:

         a. under intellectual property rights (other than patent or trademark)
            Licensable by such Contributor to use, reproduce, make available,
            modify, display, perform, distribute, and otherwise exploit its
            Contributions, either on an unmodified basis, with Modifications, or
            as part of a Larger Work; and

         b. under Patent Claims of such Contributor to make, use, sell, offer for
            sale, have made, import, and otherwise transfer either its
            Contributions or its Contributor Version.

    2.2. Effective Date

         The licenses granted in Section 2.1 with respect to any Contribution
         become effective for each Contribution on the date the Contributor first
         distributes such Contribution.

    2.3. Limitations on Grant Scope

         The licenses granted in this Section 2 are the only rights granted under
         this License. No additional rights or licenses will be implied from the
         distribution or licensing of Covered Software under this License.
         Notwithstanding Section 2.1(b) above, no patent license is granted by a
         Contributor:

         a. for any code that a Contributor has removed from Covered Software; or

         b. for infringements caused by: (i) Your and any other third party's
            modifications of Covered Software, or (ii) the combination of its
            Contributions with other software (except as part of its Contributor
            Version); or

         c. under Patent Claims infringed by Covered Software in the absence of
            its Contributions.

         This License does not grant any rights in the trademarks, service marks,
         or logos of any Contributor (except as may be necessary to comply with
         the notice requirements in Section 3.4).

    2.4. Subsequent Licenses

         No Contributor makes additional grants as a result of Your choice to
         distribute the Covered Software under a subsequent version of this
         License (see Section 10.2) or under the terms of a Secondary License (if
         permitted under the terms of Section 3.3).

    2.5. Representation

         Each Contributor represents that the Contributor believes its
         Contributions are its original creation(s) or it has sufficient rights to
         grant the rights to its Contributions conveyed by this License.

    2.6. Fair Use

         This License is not intended to limit any rights You have under
         applicable copyright doctrines of fair use, fair dealing, or other
         equivalents.

    2.7. Conditions

         Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted in
         Section 2.1.


    3. Responsibilities

    3.1. Distribution of Source Form

         All distribution of Covered Software in Source Code Form, including any
         Modifications that You create or to which You contribute, must be under
         the terms of this License. You must inform recipients that the Source
         Code Form of the Covered Software is governed by the terms of this
         License, and how they can obtain a copy of this License. You may not
         attempt to alter or restrict the recipients' rights in the Source Code
         Form.

    3.2. Distribution of Executable Form

         If You distribute Covered Software in Executable Form then:

         a. such Covered Software must also be made available in Source Code Form,
            as described in Section 3.1, and You must inform recipients of the
            Executable Form how they can obtain a copy of such Source Code Form by
            reasonable means in a timely manner, at a charge no more than the cost
            of distribution to the recipient; and

         b. You may distribute such Executable Form under the terms of this
            License, or sublicense it under different terms, provided that the
            license for the Executable Form does not attempt to limit or alter the
            recipients' rights in the Source Code Form under this License.

    3.3. Distribution of a Larger Work

         You may create and distribute a Larger Work under terms of Your choice,
         provided that You also comply with the requirements of this License for
         the Covered Software. If the Larger Work is a combination of Covered
         Software with a work governed by one or more Secondary Licenses, and the
         Covered Software is not Incompatible With Secondary Licenses, this
         License permits You to additionally distribute such Covered Software
         under the terms of such Secondary License(s), so that the recipient of
         the Larger Work may, at their option, further distribute the Covered
         Software under the terms of either this License or such Secondary
         License(s).

    3.4. Notices

         You may not remove or alter the substance of any license notices
         (including copyright notices, patent notices, disclaimers of warranty, or
         limitations of liability) contained within the Source Code Form of the
         Covered Software, except that You may alter any license notices to the
         extent required to remedy known factual inaccuracies.

    3.5. Application of Additional Terms

         You may choose to offer, and to charge a fee for, warranty, support,
         indemnity or liability obligations to one or more recipients of Covered
         Software. However, You may do so only on Your own behalf, and not on
         behalf of any Contributor. You must make it absolutely clear that any
         such warranty, support, indemnity, or liability obligation is offered by
         You alone, and You hereby agree to indemnify every Contributor for any
         liability incurred by such Contributor as a result of warranty, support,
         indemnity or liability terms You offer. You may include additional
         disclaimers of warranty and limitations of liability specific to any
         jurisdiction.

    4. Inability to Comply Due to Statute or Regulation

       If it is impossible for You to comply with any of the terms of this License
       with respect to some or all of the Covered Software due to statute,
       judicial order, or regulation then You must: (a) comply with the terms of
       this License to the maximum extent possible; and (b) describe the
       limitations and the code they affect. Such description must be placed in a
       text file included with all distributions of the Covered Software under
       this License. Except to the extent prohibited by statute or regulation,
       such description must be sufficiently detailed for a recipient of ordinary
       skill to be able to understand it.

    5. Termination

    5.1. The rights granted under this License will terminate automatically if You
         fail to comply with any of its terms. However, if You become compliant,
         then the rights granted under this License from a particular Contributor
         are reinstated (a) provisionally, unless and until such Contributor
         explicitly and finally terminates Your grants, and (b) on an ongoing
         basis, if such Contributor fails to notify You of the non-compliance by
         some reasonable means prior to 60 days after You have come back into
         compliance. Moreover, Your grants from a particular Contributor are
         reinstated on an ongoing basis if such Contributor notifies You of the
         non-compliance by some reasonable means, this is the first time You have
         received notice of non-compliance with this License from such
         Contributor, and You become compliant prior to 30 days after Your receipt
         of the notice.

    5.2. If You initiate litigation against any entity by asserting a patent
         infringement claim (excluding declaratory judgment actions,
         counter-claims, and cross-claims) alleging that a Contributor Version
         directly or indirectly infringes any patent, then the rights granted to
         You by any and all Contributors for the Covered Software under Section
         2.1 of this License shall terminate.

    5.3. In the event of termination under Sections 5.1 or 5.2 above, all end user
         license agreements (excluding distributors and resellers) which have been
         validly granted by You or Your distributors under this License prior to
         termination shall survive termination.

    6. Disclaimer of Warranty

       Covered Software is provided under this License on an "as is" basis,
       without warranty of any kind, either expressed, implied, or statutory,
       including, without limitation, warranties that the Covered Software is free
       of defects, merchantable, fit for a particular purpose or non-infringing.
       The entire risk as to the quality and performance of the Covered Software
       is with You. Should any Covered Software prove defective in any respect,
       You (not any Contributor) assume the cost of any necessary servicing,
       repair, or correction. This disclaimer of warranty constitutes an essential
       part of this License. No use of  any Covered Software is authorized under
       this License except under this disclaimer.

    7. Limitation of Liability

       Under no circumstances and under no legal theory, whether tort (including
       negligence), contract, or otherwise, shall any Contributor, or anyone who
       distributes Covered Software as permitted above, be liable to You for any
       direct, indirect, special, incidental, or consequential damages of any
       character including, without limitation, damages for lost profits, loss of
       goodwill, work stoppage, computer failure or malfunction, or any and all
       other commercial damages or losses, even if such party shall have been
       informed of the possibility of such damages. This limitation of liability
       shall not apply to liability for death or personal injury resulting from
       such party's negligence to the extent applicable law prohibits such
       limitation. Some jurisdictions do not allow the exclusion or limitation of
       incidental or consequential damages, so this exclusion and limitation may
       not apply to You.

    8. Litigation

       Any litigation relating to this License may be brought only in the courts
       of a jurisdiction where the defendant maintains its principal place of
       business and such litigation shall be governed by laws of that
       jurisdiction, without reference to its conflict-of-law provisions. Nothing
       in this Section shall prevent a party's ability to bring cross-claims or
       counter-claims.

    9. Miscellaneous

       This License represents the complete agreement concerning the subject
       matter hereof. If any provision of this License is held to be
       unenforceable, such provision shall be reformed only to the extent
       necessary to make it enforceable. Any law or regulation which provides that
       the language of a contract shall be construed against the drafter shall not
       be used to construe this License against a Contributor.


    10. Versions of the License

    10.1. New Versions

          Mozilla Foundation is the license steward. Except as provided in Section
          10.3, no one other than the license steward has the right to modify or
          publish new versions of this License. Each version will be given a
          distinguishing version number.

    10.2. Effect of New Versions

          You may distribute the Covered Software under the terms of the version
          of the License under which You originally received the Covered Software,
          or under the terms of any subsequent version published by the license
          steward.

    10.3. Modified Versions

          If you create software not governed by this License, and you want to
          create a new license for such software, you may create and use a
          modified version of this License if you rename the license and remove
          any references to the name of the license steward (except to note that
          such modified license differs from this License).

    10.4. Distributing Source Code Form that is Incompatible With Secondary
          Licenses If You choose to distribute Source Code Form that is
          Incompatible With Secondary Licenses under the terms of this version of
          the License, the notice described in Exhibit B of this License must be
          attached.

    Exhibit A - Source Code Form License Notice

          This Source Code Form is subject to the
          terms of the Mozilla Public License, v.
          2.0. If a copy of the MPL was not
          distributed with this file, You can
          obtain one at
          http://mozilla.org/MPL/2.0/.

    If it is not possible or desirable to put the notice in a particular file,
    then You may include the notice in a location (such as a LICENSE file in a
    relevant directory) where a recipient would be likely to look for such a
    notice.

    You may add additional accurate notices of copyright ownership.

    Exhibit B - "Incompatible With Secondary Licenses" Notice

          This Source Code Form is "Incompatible
          With Secondary Licenses", as defined by
          the Mozilla Public License, v. 2.0.
    ```

    <a id="L14"></a>

    ### L14: BSD-3-Clause

    Applies to:

    - github.com/hashicorp/golang-lru/v2 (`simplelru/LICENSE_list`) -- Copyright (c) 2009 The Go Authors. All rights reserved.

    ```text
    This license applies to simplelru/list.go

    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    <a id="L15"></a>

    ### L15: MIT

    Applies to:

    - github.com/mattn/go-isatty -- Copyright (c) Yasuhiro MATSUMOTO <mattn.jp@gmail.com>

    ```text
    Copyright (c) Yasuhiro MATSUMOTO <mattn.jp@gmail.com>

    MIT License (Expat)

    Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    ```

    <a id="L16"></a>

    ### L16: BSD-3-Clause

    Applies to:

    - modernc.org/gc/v2 -- Copyright (c) 2016 The GC Authors. All rights reserved.
    - modernc.org/gc/v3 -- Copyright (c) 2016 The GC Authors. All rights reserved.

    ```text
    -------------------------------------------------------------------------------
    Copyright (c) 2016 The GC Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the names of the authors nor the names of the
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    -------------------------------------------------------------------------------

    Code in this repository contains or may contain

        - copied original code from
        - code based on original code from
        - code inspired by original code in

        "The Go Programming Language" project at https://go.googlesource.com/go/.

    Copy of the license of the original code follows below

    -------------------------------------------------------------------------------
    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    -------------------------------------------------------------------------------
    ```

    <a id="L17"></a>

    ### L17: BSD-3-Clause

    Applies to:

    - modernc.org/goabi0 -- Copyright (c) 2025 The goabi0 Authors. All rights reserved.

    ```text
    Copyright (c) 2025 The goabi0 Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

    3. Neither the name of the copyright holder nor the names of its contributors
    may be used to endorse or promote products derived from this software without
    specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ```

    ## Appendix B: inherited third-party notices

    These documents are the transitive tail: notices that a dependency carries for code of
    its own that came from somewhere else. They are reproduced verbatim, with only the
    Markdown heading levels shifted so they nest inside this file.

    <a id="N1"></a>

    ### N1: `LICENSE-3RD-PARTY.md` from modernc.org/libc

    Covers: Go (BSD-3-Clause), musl libc (MIT), go-netdb (MIT), NixOS/nixpkgs (MIT).

    ---

    #### Third-Party Software Notices

    This repository contains code and assets acquired from third-party sources.
    While the main project is licensed under the BSD-3 License, the components
    listed below are subject to their own specific license terms and copyright
    notices.

    The following is a list of third-party software included in this repository,
    their locations, and their respective licenses.


    ----

    ##### Go

    * **URL:** https://github.com/golang/go
    ----

    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

    ----

    ##### musl libc

    * **URL:** https://musl.libc.org/

    ----

    musl as a whole is licensed under the following standard MIT license:

    ----------------------------------------------------------------------
    Copyright © 2005-2020 Rich Felker, et al.

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    ----------------------------------------------------------------------

    Authors/contributors include:

    A. Wilcox
    Ada Worcester
    Alex Dowad
    Alex Suykov
    Alexander Monakov
    Andre McCurdy
    Andrew Kelley
    Anthony G. Basile
    Aric Belsito
    Arvid Picciani
    Bartosz Brachaczek
    Benjamin Peterson
    Bobby Bingham
    Boris Brezillon
    Brent Cook
    Chris Spiegel
    Clément Vasseur
    Daniel Micay
    Daniel Sabogal
    Daurnimator
    David Carlier
    David Edelsohn
    Denys Vlasenko
    Dmitry Ivanov
    Dmitry V. Levin
    Drew DeVault
    Emil Renner Berthing
    Fangrui Song
    Felix Fietkau
    Felix Janda
    Gianluca Anzolin
    Hauke Mehrtens
    He X
    Hiltjo Posthuma
    Isaac Dunham
    Jaydeep Patil
    Jens Gustedt
    Jeremy Huntwork
    Jo-Philipp Wich
    Joakim Sindholt
    John Spencer
    Julien Ramseier
    Justin Cormack
    Kaarle Ritvanen
    Khem Raj
    Kylie McClain
    Leah Neukirchen
    Luca Barbato
    Luka Perkov
    M Farkas-Dyck (Strake)
    Mahesh Bodapati
    Markus Wichmann
    Masanori Ogino
    Michael Clark
    Michael Forney
    Mikhail Kremnyov
    Natanael Copa
    Nicholas J. Kain
    orc
    Pascal Cuoq
    Patrick Oppenlander
    Petr Hosek
    Petr Skocik
    Pierre Carrier
    Reini Urban
    Rich Felker
    Richard Pennington
    Ryan Fairfax
    Samuel Holland
    Segev Finer
    Shiz
    sin
    Solar Designer
    Stefan Kristiansson
    Stefan O'Rear
    Szabolcs Nagy
    Timo Teräs
    Trutz Behn
    Valentin Ochs
    Will Dietz
    William Haddon
    William Pitcock

    Portions of this software are derived from third-party works licensed
    under terms compatible with the above MIT license:

    The TRE regular expression implementation (src/regex/reg* and
    src/regex/tre*) is Copyright © 2001-2008 Ville Laurikari and licensed
    under a 2-clause BSD license (license text in the source files). The
    included version has been heavily modified by Rich Felker in 2012, in
    the interests of size, simplicity, and namespace cleanliness.

    Much of the math library code (src/math/* and src/complex/*) is
    Copyright © 1993,2004 Sun Microsystems or
    Copyright © 2003-2011 David Schultz or
    Copyright © 2003-2009 Steven G. Kargl or
    Copyright © 2003-2009 Bruce D. Evans or
    Copyright © 2008 Stephen L. Moshier or
    Copyright © 2017-2018 Arm Limited
    and labelled as such in comments in the individual source files. All
    have been licensed under extremely permissive terms.

    The ARM memcpy code (src/string/arm/memcpy.S) is Copyright © 2008
    The Android Open Source Project and is licensed under a two-clause BSD
    license. It was taken from Bionic libc, used on Android.

    The AArch64 memcpy and memset code (src/string/aarch64/*) are
    Copyright © 1999-2019, Arm Limited.

    The implementation of DES for crypt (src/crypt/crypt_des.c) is
    Copyright © 1994 David Burren. It is licensed under a BSD license.

    The implementation of blowfish crypt (src/crypt/crypt_blowfish.c) was
    originally written by Solar Designer and placed into the public
    domain. The code also comes with a fallback permissive license for use
    in jurisdictions that may not recognize the public domain.

    The smoothsort implementation (src/stdlib/qsort.c) is Copyright © 2011
    Valentin Ochs and is licensed under an MIT-style license.

    The x86_64 port was written by Nicholas J. Kain and is licensed under
    the standard MIT terms.

    The mips and microblaze ports were originally written by Richard
    Pennington for use in the ellcc project. The original code was adapted
    by Rich Felker for build system and code conventions during upstream
    integration. It is licensed under the standard MIT terms.

    The mips64 port was contributed by Imagination Technologies and is
    licensed under the standard MIT terms.

    The powerpc port was also originally written by Richard Pennington,
    and later supplemented and integrated by John Spencer. It is licensed
    under the standard MIT terms.

    All other files which have no copyright comments are original works
    produced specifically for use as part of this library, written either
    by Rich Felker, the main author of the library, or by one or more
    contibutors listed above. Details on authorship of individual files
    can be found in the git version control history of the project. The
    omission of copyright and license comments in each file is in the
    interest of source tree size.

    In addition, permission is hereby granted for all public header files
    (include/* and arch/*/bits/*) and crt files intended to be linked into
    applications (crt/*, ldso/dlstart.c, and arch/*/crt_arch.h) to omit
    the copyright notice and permission notice otherwise required by the
    license, and to use these files without any requirement of
    attribution. These files include substantial contributions from:

    Bobby Bingham
    John Spencer
    Nicholas J. Kain
    Rich Felker
    Richard Pennington
    Stefan Kristiansson
    Szabolcs Nagy

    all of whom have explicitly granted such permission.

    This file previously contained text expressing a belief that most of
    the files covered by the above exception were sufficiently trivial not
    to be subject to copyright, resulting in confusion over whether it
    negated the permissions granted in the license. In the spirit of
    permissive licensing, and of not having licensing issues being an
    obstacle to adoption, that text has been removed.

    ----

    ##### go-netdb

    * **URL:** https://github.com/dominikh/go-netdb

    ----

    Copyright (c) 2012 Dominik Honnef

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    ----

    ##### NixOS/nixpkgs

    * **URL:** https://github.com/NixOS/nixpkgs

    ----

    Copyright (c) 2003-2025 Eelco Dolstra and the Nixpkgs/NixOS contributors

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
    LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
    OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
    WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    ---

### modernc.org/sqlite v1.60.1 / LICENSE-SQLITE

    SQLite Is Public Domain

    All of the code and documentation in SQLite has been dedicated to the public
    domain by the authors. All code authors, and representatives of the companies
    they work for, have signed affidavits dedicating their contributions to the
    public domain and originals of those signed affidavits are stored in a firesafe
    at the main offices of Hwaci. Anyone is free to copy, modify, publish, use,
    compile, sell, or distribute the original SQLite code, either in source code
    form or as a compiled binary, for any purpose, commercial or non-commercial,
    and by any means.

    The previous paragraph applies to the deliverable code and documentation in
    SQLite - those parts of the SQLite library that you actually bundle and ship
    with a larger application. Some scripts used as part of the build process (for
    example the "configure" scripts generated by autoconf) might fall under other
    open-source licenses. Nothing from these build scripts ever reaches the final
    deliverable SQLite library, however, and so the licenses associated with those
    scripts should not be a factor in assessing your rights to copy and use the
    SQLite library.

    All of the deliverable code in SQLite has been written from scratch. No code
    has been taken from other projects or from the open internet. Every line of
    code can be traced back to its original author, and all of those authors have
    public domain dedications on file. So the SQLite code base is clean and is
    uncontaminated with licensed code from other projects.

### modernc.org/sqlite v1.60.1 / LICENSE-SQLITE_VEC

    MIT License

    Copyright (c) 2024 Alex Garcia

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

### modernc.org/libc v1.77.1 / LICENSE

    Copyright (c) 2017 The Libc Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the names of the authors nor the names of the
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### modernc.org/libc v1.77.1 / LICENSE-3RD-PARTY.md

    # Third-Party Software Notices

    This repository contains code and assets acquired from third-party sources.
    While the main project is licensed under the BSD-3 License, the components
    listed below are subject to their own specific license terms and copyright
    notices.

    The following is a list of third-party software included in this repository,
    their locations, and their respective licenses.


    ----

    ## Go

    * **URL:** https://github.com/golang/go
    ----

    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

    ----

    ## musl libc

    * **URL:** https://musl.libc.org/

    ----

    musl as a whole is licensed under the following standard MIT license:

    ----------------------------------------------------------------------
    Copyright © 2005-2020 Rich Felker, et al.

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    ----------------------------------------------------------------------

    Authors/contributors include:

    A. Wilcox
    Ada Worcester
    Alex Dowad
    Alex Suykov
    Alexander Monakov
    Andre McCurdy
    Andrew Kelley
    Anthony G. Basile
    Aric Belsito
    Arvid Picciani
    Bartosz Brachaczek
    Benjamin Peterson
    Bobby Bingham
    Boris Brezillon
    Brent Cook
    Chris Spiegel
    Clément Vasseur
    Daniel Micay
    Daniel Sabogal
    Daurnimator
    David Carlier
    David Edelsohn
    Denys Vlasenko
    Dmitry Ivanov
    Dmitry V. Levin
    Drew DeVault
    Emil Renner Berthing
    Fangrui Song
    Felix Fietkau
    Felix Janda
    Gianluca Anzolin
    Hauke Mehrtens
    He X
    Hiltjo Posthuma
    Isaac Dunham
    Jaydeep Patil
    Jens Gustedt
    Jeremy Huntwork
    Jo-Philipp Wich
    Joakim Sindholt
    John Spencer
    Julien Ramseier
    Justin Cormack
    Kaarle Ritvanen
    Khem Raj
    Kylie McClain
    Leah Neukirchen
    Luca Barbato
    Luka Perkov
    M Farkas-Dyck (Strake)
    Mahesh Bodapati
    Markus Wichmann
    Masanori Ogino
    Michael Clark
    Michael Forney
    Mikhail Kremnyov
    Natanael Copa
    Nicholas J. Kain
    orc
    Pascal Cuoq
    Patrick Oppenlander
    Petr Hosek
    Petr Skocik
    Pierre Carrier
    Reini Urban
    Rich Felker
    Richard Pennington
    Ryan Fairfax
    Samuel Holland
    Segev Finer
    Shiz
    sin
    Solar Designer
    Stefan Kristiansson
    Stefan O'Rear
    Szabolcs Nagy
    Timo Teräs
    Trutz Behn
    Valentin Ochs
    Will Dietz
    William Haddon
    William Pitcock

    Portions of this software are derived from third-party works licensed
    under terms compatible with the above MIT license:

    The TRE regular expression implementation (src/regex/reg* and
    src/regex/tre*) is Copyright © 2001-2008 Ville Laurikari and licensed
    under a 2-clause BSD license (license text in the source files). The
    included version has been heavily modified by Rich Felker in 2012, in
    the interests of size, simplicity, and namespace cleanliness.

    Much of the math library code (src/math/* and src/complex/*) is
    Copyright © 1993,2004 Sun Microsystems or
    Copyright © 2003-2011 David Schultz or
    Copyright © 2003-2009 Steven G. Kargl or
    Copyright © 2003-2009 Bruce D. Evans or
    Copyright © 2008 Stephen L. Moshier or
    Copyright © 2017-2018 Arm Limited
    and labelled as such in comments in the individual source files. All
    have been licensed under extremely permissive terms.

    The ARM memcpy code (src/string/arm/memcpy.S) is Copyright © 2008
    The Android Open Source Project and is licensed under a two-clause BSD
    license. It was taken from Bionic libc, used on Android.

    The AArch64 memcpy and memset code (src/string/aarch64/*) are
    Copyright © 1999-2019, Arm Limited.

    The implementation of DES for crypt (src/crypt/crypt_des.c) is
    Copyright © 1994 David Burren. It is licensed under a BSD license.

    The implementation of blowfish crypt (src/crypt/crypt_blowfish.c) was
    originally written by Solar Designer and placed into the public
    domain. The code also comes with a fallback permissive license for use
    in jurisdictions that may not recognize the public domain.

    The smoothsort implementation (src/stdlib/qsort.c) is Copyright © 2011
    Valentin Ochs and is licensed under an MIT-style license.

    The x86_64 port was written by Nicholas J. Kain and is licensed under
    the standard MIT terms.

    The mips and microblaze ports were originally written by Richard
    Pennington for use in the ellcc project. The original code was adapted
    by Rich Felker for build system and code conventions during upstream
    integration. It is licensed under the standard MIT terms.

    The mips64 port was contributed by Imagination Technologies and is
    licensed under the standard MIT terms.

    The powerpc port was also originally written by Richard Pennington,
    and later supplemented and integrated by John Spencer. It is licensed
    under the standard MIT terms.

    All other files which have no copyright comments are original works
    produced specifically for use as part of this library, written either
    by Rich Felker, the main author of the library, or by one or more
    contibutors listed above. Details on authorship of individual files
    can be found in the git version control history of the project. The
    omission of copyright and license comments in each file is in the
    interest of source tree size.

    In addition, permission is hereby granted for all public header files
    (include/* and arch/*/bits/*) and crt files intended to be linked into
    applications (crt/*, ldso/dlstart.c, and arch/*/crt_arch.h) to omit
    the copyright notice and permission notice otherwise required by the
    license, and to use these files without any requirement of
    attribution. These files include substantial contributions from:

    Bobby Bingham
    John Spencer
    Nicholas J. Kain
    Rich Felker
    Richard Pennington
    Stefan Kristiansson
    Szabolcs Nagy

    all of whom have explicitly granted such permission.

    This file previously contained text expressing a belief that most of
    the files covered by the above exception were sufficiently trivial not
    to be subject to copyright, resulting in confusion over whether it
    negated the permissions granted in the license. In the spirit of
    permissive licensing, and of not having licensing issues being an
    obstacle to adoption, that text has been removed.

    ----

    ## go-netdb

    * **URL:** https://github.com/dominikh/go-netdb

    ----

    Copyright (c) 2012 Dominik Honnef

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    ----

    ## NixOS/nixpkgs

    * **URL:** https://github.com/NixOS/nixpkgs

    ----

    Copyright (c) 2003-2025 Eelco Dolstra and the Nixpkgs/NixOS contributors

    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
    LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
    OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
    WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### modernc.org/memory v1.12.1 / LICENSE

    Copyright (c) 2017 The Memory Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the names of the authors nor the names of the
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### modernc.org/memory v1.12.1 / LICENSE-GO

    Copyright (c) 2009 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### modernc.org/memory v1.12.1 / LICENSE-MMAP-GO

    Copyright (c) 2011, Evan Shaw <edsrzf@gmail.com>
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
        * Redistributions of source code must retain the above copyright
          notice, this list of conditions and the following disclaimer.
        * Redistributions in binary form must reproduce the above copyright
          notice, this list of conditions and the following disclaimer in the
          documentation and/or other materials provided with the distribution.
        * Neither the name of the copyright holder nor the
          names of its contributors may be used to endorse or promote products
          derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


### modernc.org/mathutil v1.7.1 / LICENSE

    Copyright (c) 2014 The mathutil Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the names of the authors nor the names of the
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### github.com/dustin/go-humanize v1.0.1 / LICENSE

    Copyright (c) 2005-2008  Dustin Sallings <dustin@spy.net>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

    <http://www.opensource.org/licenses/mit-license.php>

### github.com/google/uuid v1.6.0 / LICENSE

    Copyright (c) 2009,2014 Google Inc. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### github.com/ncruces/go-strftime v1.0.0 / LICENSE

    MIT License

    Copyright (c) 2022 Nuno Cruces

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

### github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec / LICENSE

    Copyright (c) 2012 The Go Authors. All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are
    met:

       * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
       * Redistributions in binary form must reproduce the above
    copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the
    distribution.
       * Neither the name of Google Inc. nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
