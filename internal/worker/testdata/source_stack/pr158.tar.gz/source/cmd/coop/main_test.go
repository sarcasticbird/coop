package main

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"slices"
	"strings"
	"testing"

	"github.com/sarcasticbird/coop/image"
	"github.com/sarcasticbird/coop/internal/config"
	"github.com/sarcasticbird/coop/internal/core"
	"github.com/sarcasticbird/coop/internal/releasetool"
	"github.com/sarcasticbird/coop/internal/runtime"
	"github.com/sarcasticbird/coop/internal/session"
	"github.com/sarcasticbird/coop/internal/tui"
)

func TestUpgradeChangedLockPrintsVersionsAndRebuildGuidance(t *testing.T) {
	withUpgradeCore(t, func(context.Context, io.Writer, io.Writer) (core.UpgradeResult, error) {
		return core.UpgradeResult{
			Changed: true,
			Changes: []core.PackageChange{{Name: "codex", From: "0.144.4", To: "0.146.0"}},
		}, nil
	})
	t.Chdir(t.TempDir()) // upgrade is machine-wide, not project-scoped
	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{"upgrade"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{
		"codex: 0.144.4 -> 0.146.0",
		"Core lock upgraded.",
		"Existing coops are stale",
		"coop rebuild",
	} {
		if !strings.Contains(output.String(), want) {
			t.Fatalf("upgrade output missing %q:\n%s", want, output.String())
		}
	}
}

func TestUpgradeChangedRevisionWithoutVersionChangeStillMarksCoopsStale(t *testing.T) {
	withUpgradeCore(t, func(context.Context, io.Writer, io.Writer) (core.UpgradeResult, error) {
		return core.UpgradeResult{Changed: true}, nil
	})
	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{"upgrade"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(output.String(), "Core package revisions changed.") ||
		!strings.Contains(output.String(), "Existing coops are stale") {
		t.Fatalf("revision-only output:\n%s", output.String())
	}
}

func TestUpgradeUnchangedReportsCurrentWithoutStaleWarning(t *testing.T) {
	withUpgradeCore(t, func(context.Context, io.Writer, io.Writer) (core.UpgradeResult, error) {
		return core.UpgradeResult{}, nil
	})
	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{"upgrade"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(output.String(), "already up to date") ||
		strings.Contains(output.String(), "stale") {
		t.Fatalf("unchanged output:\n%s", output.String())
	}
}

func TestUpgradeFailureDoesNotInvokeAnyProjectLifecycleOperation(t *testing.T) {
	withUpgradeCore(t, func(context.Context, io.Writer, io.Writer) (core.UpgradeResult, error) {
		return core.UpgradeResult{}, errors.New("network unavailable")
	})
	oldRuntime := newRuntime
	runtimeCalled := false
	newRuntime = func() runtime.Runtime {
		runtimeCalled = true
		return runtime.NewMock()
	}
	t.Cleanup(func() { newRuntime = oldRuntime })
	cmd := root()
	cmd.SetArgs([]string{"upgrade"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "network unavailable") {
		t.Fatalf("error = %v", err)
	}
	if runtimeCalled {
		t.Fatal("upgrade invoked project container runtime")
	}
}

func TestRebuildMaterializesAndNamesImageFromActiveCoreLock(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	withStopBuilderHook(t, nil)
	xdg := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(xdg, "config"))
	t.Setenv("XDG_STATE_HOME", filepath.Join(xdg, "state"))
	t.Setenv("XDG_CACHE_HOME", filepath.Join(xdg, "cache"))
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	active := changedCoreVersion(t, image.EmbeddedCoreLock(), "codex", "99.0.0")
	stateDir := filepath.Join(xdg, "state", "coop")
	if err := core.Install(stateDir, active); err != nil {
		t.Fatal(err)
	}
	cfg, err := config.Load(project)
	if err != nil {
		t.Fatal(err)
	}
	wantImage := session.EffectiveImageNameWithCoreLock(cfg, mustLoadCore(t, stateDir))

	oldBuild := buildImage
	buildImage = func(args []string, _, _ io.Writer) error {
		if len(args) < 3 || args[0] != "build" || args[1] != "-t" || args[2] != wantImage {
			return errors.New("rebuild used wrong active-core image tag")
		}
		got, err := os.ReadFile(filepath.Join(args[len(args)-1], "core", ".flox", "env", "manifest.lock"))
		if err != nil {
			return err
		}
		var gotJSON, wantJSON any
		if err := json.Unmarshal(got, &gotJSON); err != nil {
			return err
		}
		if err := json.Unmarshal(active, &wantJSON); err != nil {
			return err
		}
		if !reflect.DeepEqual(gotJSON, wantJSON) {
			return errors.New("rebuild materialized wrong active core lock")
		}
		return nil
	}
	t.Cleanup(func() { buildImage = oldBuild })

	cmd := root()
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
}

func TestRebuildResolvesMaterializesAndLocksGitHubReleaseTools(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	withStopBuilderHook(t, nil)
	xdg := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdg)
	t.Setenv("XDG_STATE_HOME", filepath.Join(xdg, "state"))
	if err := os.MkdirAll(filepath.Join(xdg, "coop"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(xdg, "coop", "coop.toml"), []byte(`
[[tools.github_release]]
name = "kata"
repo = "kenn-io/kata"
tag = "latest"
asset = "kata_{version}_linux_arm64.tar.gz"
binary = "kata"
`), 0o644); err != nil {
		t.Fatal(err)
	}
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	cached := filepath.Join(t.TempDir(), "kata")
	if err := os.WriteFile(cached, []byte("verified-kata"), 0o755); err != nil {
		t.Fatal(err)
	}
	resolved := []config.ResolvedReleaseTool{{
		Name: "kata", Repo: "kenn-io/kata", RequestedTag: "latest", Tag: "v0.10.0",
		Asset: "kata_0.10.0_linux_arm64.tar.gz", Digest: "sha256:" + strings.Repeat("a", 64),
		Binary: "kata", CachePath: cached,
	}}

	oldResolve, oldSave, oldPrune, oldBuild := resolveReleaseTools, saveReleaseToolLock, pruneReleaseToolCache, buildImage
	resolveReleaseTools = func(context.Context, []config.GitHubReleaseTool) ([]config.ResolvedReleaseTool, error) {
		return resolved, nil
	}
	saved := false
	pruned := false
	saveReleaseToolLock = func(_ string, projectRoot string, specs []config.GitHubReleaseTool, got []config.ResolvedReleaseTool) error {
		saved = len(specs) == 1 && slices.EqualFunc(got, resolved, func(a, b config.ResolvedReleaseTool) bool {
			return a.Name == b.Name && a.Digest == b.Digest
		}) && projectRoot != ""
		return nil
	}
	pruneReleaseToolCache = func(_ string, got []config.ResolvedReleaseTool) error {
		pruned = len(got) == 1 && got[0].Digest == resolved[0].Digest
		return nil
	}
	buildImage = func(args []string, _, _ io.Writer) error {
		archive, err := os.Open(filepath.Join(args[len(args)-1], "release-tools.tar.gz"))
		if err != nil {
			return err
		}
		defer func() { _ = archive.Close() }()
		gz, err := gzip.NewReader(archive)
		if err != nil {
			return err
		}
		defer func() { _ = gz.Close() }()
		tr := tar.NewReader(gz)
		header, err := tr.Next()
		if err != nil {
			return err
		}
		data, err := io.ReadAll(tr)
		if err != nil {
			return err
		}
		if header.Name != "kata" {
			return errors.New("wrong release executable name")
		}
		if string(data) != "verified-kata" {
			return errors.New("wrong release executable")
		}
		return nil
	}
	t.Cleanup(func() {
		resolveReleaseTools, saveReleaseToolLock, pruneReleaseToolCache, buildImage = oldResolve, oldSave, oldPrune, oldBuild
	})

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !saved {
		t.Fatal("successful rebuild did not save resolved release lock")
	}
	if !pruned {
		t.Fatal("successful rebuild did not prune stale release cache entries")
	}
	if !strings.Contains(output.String(), "release tools:  kata@v0.10.0") {
		t.Fatalf("rebuild output missing resolved release: %s", output.String())
	}
}

func TestRebuildDoesNotSaveReleaseLockWhenImageBuildFails(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	withStopBuilderHook(t, nil)
	xdg := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdg)
	t.Setenv("XDG_STATE_HOME", filepath.Join(xdg, "state"))
	t.Setenv("XDG_CACHE_HOME", filepath.Join(xdg, "cache"))
	if err := os.MkdirAll(filepath.Join(xdg, "coop"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(xdg, "coop", "coop.toml"), []byte(`
[[tools.github_release]]
name = "kata"
repo = "kenn-io/kata"
tag = "latest"
asset = "kata_{version}_linux_arm64.tar.gz"
binary = "kata"
`), 0o644); err != nil {
		t.Fatal(err)
	}
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	cfg, err := config.Load(project)
	if err != nil {
		t.Fatal(err)
	}
	oldResolved := []config.ResolvedReleaseTool{{
		Name: "kata", Repo: "kenn-io/kata", RequestedTag: "latest", Tag: "v0.9.0",
		Asset:  "kata_0.9.0_linux_arm64.tar.gz",
		Digest: "sha256:" + strings.Repeat("9", 64), Binary: "kata",
	}}
	stateDir := filepath.Join(xdg, "state", "coop")
	if err := releasetool.SaveLock(stateDir, project, cfg.Tools.GitHubReleases, oldResolved); err != nil {
		t.Fatal(err)
	}
	cached := filepath.Join(t.TempDir(), "kata")
	if err := os.WriteFile(cached, []byte("new-kata"), 0o755); err != nil {
		t.Fatal(err)
	}
	newResolved := []config.ResolvedReleaseTool{{
		Name: "kata", Repo: "kenn-io/kata", RequestedTag: "latest", Tag: "v0.10.0",
		Asset:  "kata_0.10.0_linux_arm64.tar.gz",
		Digest: "sha256:" + strings.Repeat("a", 64), Binary: "kata", CachePath: cached,
	}}

	oldResolve, oldSave, oldPrune, oldBuild := resolveReleaseTools, saveReleaseToolLock, pruneReleaseToolCache, buildImage
	resolveReleaseTools = func(context.Context, []config.GitHubReleaseTool) ([]config.ResolvedReleaseTool, error) {
		return newResolved, nil
	}
	saveReleaseToolLock = func(string, string, []config.GitHubReleaseTool, []config.ResolvedReleaseTool) error {
		t.Fatal("failed build saved release lock")
		return nil
	}
	pruneReleaseToolCache = func(string, []config.ResolvedReleaseTool) error {
		t.Fatal("failed build pruned release cache")
		return nil
	}
	buildImage = func([]string, io.Writer, io.Writer) error { return errors.New("build failed") }
	t.Cleanup(func() {
		resolveReleaseTools, saveReleaseToolLock, pruneReleaseToolCache, buildImage = oldResolve, oldSave, oldPrune, oldBuild
	})

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err == nil || !strings.Contains(err.Error(), "build failed") {
		t.Fatalf("build failure = %v", err)
	}
	got, err := releasetool.LoadLock(stateDir, cfg.Tools.GitHubReleases)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Tag != "v0.9.0" {
		t.Fatalf("failed build replaced previous lock: %+v", got)
	}
}

func TestRebuildWithoutReleaseToolsPersistsEmptyStateAndPrunesCache(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	withStopBuilderHook(t, nil)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	oldSave, oldPrune, oldBuild := saveReleaseToolLock, pruneReleaseToolCache, buildImage
	saved, pruned := false, false
	saveReleaseToolLock = func(_ string, projectRoot string, specs []config.GitHubReleaseTool, resolved []config.ResolvedReleaseTool) error {
		saved = projectRoot != "" && len(specs) == 0 && len(resolved) == 0
		return nil
	}
	pruneReleaseToolCache = func(_ string, resolved []config.ResolvedReleaseTool) error {
		pruned = len(resolved) == 0
		return nil
	}
	buildImage = func([]string, io.Writer, io.Writer) error { return nil }
	t.Cleanup(func() {
		saveReleaseToolLock, pruneReleaseToolCache, buildImage = oldSave, oldPrune, oldBuild
	})

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !saved || !pruned {
		t.Fatalf("release-free rebuild cleanup: saved=%t pruned=%t", saved, pruned)
	}
}

func TestRebuildPrintsCanonicalInputsAndPreservesContainerOnFailure(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	withStopBuilderHook(t, nil)
	xdg := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdg)
	if err := os.MkdirAll(filepath.Join(xdg, "coop"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(xdg, "coop", "coop.toml"), []byte("[tools]\npackages = [\"bat\"]\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), []byte("[tools]\npackages = [\"shellcheck\", \"actionlint\"]\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)

	oldBuild := buildImage
	var gotArgs []string
	var packageInput string
	buildImage = func(args []string, _, _ io.Writer) error {
		gotArgs = slices.Clone(args)
		data, err := os.ReadFile(filepath.Join(args[len(args)-1], "configured-packages.txt"))
		if err != nil {
			t.Fatal(err)
		}
		packageInput = string(data)
		return errors.New("resolver failed")
	}
	t.Cleanup(func() { buildImage = oldBuild })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{"rebuild"})
	err := cmd.Execute()
	wantBuildError := "build image \"" + gotArgs[2] + "\": resolver failed"
	if err == nil || !strings.Contains(err.Error(), wantBuildError) {
		t.Fatalf("build error = %v", err)
	}
	for _, want := range []string{
		"core tools:     26 packages",
		"global tools:   bat",
		"project tools:  actionlint, shellcheck",
		"image:          coop:local-",
	} {
		if !strings.Contains(output.String(), want) {
			t.Errorf("rebuild output missing %q:\n%s", want, output.String())
		}
	}
	if strings.Contains(strings.Join(gotArgs, " "), "EXTRA_PKGS") {
		t.Fatalf("build argv contains legacy shell package input: %v", gotArgs)
	}
	wantInput := image.NixpkgsRef + "#actionlint\n" + image.NixpkgsRef + "#bat\n" + image.NixpkgsRef + "#shellcheck\n"
	if packageInput != wantInput {
		t.Fatalf("configured package input = %q, want %q", packageInput, wantInput)
	}
	if len(m.Stopped) != 0 || len(m.Removed) != 0 {
		t.Fatalf("failed rebuild mutated container: stopped=%v removed=%v", m.Stopped, m.Removed)
	}
}

func TestBuildImageWrapsCommandError(t *testing.T) {
	t.Setenv("PATH", t.TempDir())

	err := buildImage([]string{"build"}, io.Discard, io.Discard)
	if err == nil || !strings.Contains(err.Error(), "run container image build") {
		t.Fatalf("build error = %v", err)
	}
}

func TestStatusReportsDesiredRunningAndPendingState(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	s, err := session.New(m, project)
	if err != nil {
		t.Fatal(err)
	}
	m.Existing[s.Name] = true
	m.Started = append(m.Started, s.Name)
	m.Images = map[string]bool{session.EffectiveImageName(s.Cfg): true}
	m.ContainerImages = map[string]string{s.Name: "coop:local-old"}
	m.ContainerLabels = map[string]map[string]string{s.Name: {session.SpecLabel: "old-spec"}}

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetArgs([]string{"status"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{
		"state:              running",
		"running image:      coop:local-old",
		"desired image:      " + session.EffectiveImageName(s.Cfg),
		"rebuild required:   no",
		"maintenance pending: yes",
	} {
		if !strings.Contains(output.String(), want) {
			t.Errorf("status output missing %q:\n%s", want, output.String())
		}
	}
}

func configureMalformedReleaseToolWarning(t *testing.T) {
	t.Helper()
	xdgConfig := t.TempDir()
	xdgState := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdgConfig)
	t.Setenv("XDG_STATE_HOME", xdgState)

	spec := []config.GitHubReleaseTool{{
		Name: "kata", Repo: "kenn-io/kata", Tag: "latest",
		Asset: "kata_{version}_linux_arm64.tar.gz", Binary: "kata",
	}}
	content := `[tools]
[[tools.github_release]]
name = "kata"
repo = "kenn-io/kata"
tag = "latest"
asset = "kata_{version}_linux_arm64.tar.gz"
binary = "kata"
`
	if err := os.MkdirAll(filepath.Join(xdgConfig, "coop"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(xdgConfig, "coop", "coop.toml"), []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
	lockPath := filepath.Join(xdgState, "coop", "release-tools", config.ReleaseSpecFingerprint(spec)+".lock")
	if err := os.MkdirAll(filepath.Dir(lockPath), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(lockPath, []byte("{not json"), 0o600); err != nil {
		t.Fatal(err)
	}
}

func TestStatusEmitsConfigWarnings(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	configureMalformedReleaseToolWarning(t)
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)

	oldWarnings := warningOutput
	var warnings bytes.Buffer
	warningOutput = &warnings
	t.Cleanup(func() { warningOutput = oldWarnings })
	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetArgs([]string{"status"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if got := strings.Count(warnings.String(), "invalid GitHub release tool state ignored"); got != 1 {
		t.Fatalf("configuration warning count = %d:\n%s", got, warnings.String())
	}
}

type failingWriter struct{}

func (failingWriter) Write([]byte) (int, error) { return 0, errors.New("sink failed") }

func emptyProject(t *testing.T) {
	t.Helper()
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
}

func TestStatusPropagatesOutputWriteFailure(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)

	cmd := root()
	cmd.SetOut(failingWriter{})
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"status"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "write status") {
		t.Fatalf("status write failure not propagated: %v", err)
	}
}

func TestRebuildPropagatesOutputWriteFailure(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)

	cmd := root()
	cmd.SetOut(failingWriter{})
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "write rebuild summary") {
		t.Fatalf("rebuild write failure not propagated: %v", err)
	}
}

func TestConfigWarningWriteFailureDoesNotBlockCommand(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	configureMalformedReleaseToolWarning(t)
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)

	oldWarnings := warningOutput
	warningOutput = failingWriter{}
	t.Cleanup(func() { warningOutput = oldWarnings })
	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"status"})
	if err := cmd.Execute(); err != nil {
		t.Fatalf("advisory warning blocked command: %v", err)
	}
}

func withStopBuilderHook(t *testing.T, stopErr error) *int {
	t.Helper()
	old := stopBuilder
	stops := new(int)
	stopBuilder = func() error { *stops++; return stopErr }
	t.Cleanup(func() { stopBuilder = old })
	return stops
}

// startBuilder marks the buildkit builder container as already running.
func startBuilder(m *runtime.Mock) {
	m.Existing[builderContainerName] = true
	m.Started = append(m.Started, builderContainerName)
}

func TestRebuildStopsBuilderItStarted(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	stops := withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func([]string, io.Writer, io.Writer) error { return nil }
	t.Cleanup(func() { buildImage = oldBuild })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if *stops != 1 {
		t.Fatalf("builder stops = %d, want 1", *stops)
	}
}

func TestRebuildLeavesPreRunningBuilderAlone(t *testing.T) {
	m := runtime.NewMock()
	startBuilder(m)
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	stops := withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func([]string, io.Writer, io.Writer) error { return nil }
	t.Cleanup(func() { buildImage = oldBuild })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if *stops != 0 {
		t.Fatalf("builder stops = %d, want 0 (builder was already running)", *stops)
	}
}

func TestRebuildStopFailureWarnsButSucceeds(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	withStopBuilderHook(t, errors.New("builder busy"))
	oldBuild := buildImage
	buildImage = func([]string, io.Writer, io.Writer) error { return nil }
	t.Cleanup(func() { buildImage = oldBuild })

	var errOut bytes.Buffer
	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(&errOut)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatalf("stop failure must not fail rebuild: %v", err)
	}
	if !strings.Contains(errOut.String(), "coop: warning: stop builder VM: builder busy") {
		t.Fatalf("missing stop warning:\n%s", errOut.String())
	}
}

func TestRebuildStopsBuilderEvenWhenBuildFails(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	stops := withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func([]string, io.Writer, io.Writer) error { return errors.New("build failed") }
	t.Cleanup(func() { buildImage = oldBuild })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err == nil {
		t.Fatal("build failure must propagate")
	}
	if *stops != 1 {
		t.Fatalf("builder stops = %d, want 1 (stop still runs on build failure)", *stops)
	}
}

func withTerminalStdin(t *testing.T, isTTY bool) {
	t.Helper()
	old := stdinIsTerminal
	stdinIsTerminal = func() bool { return isTTY }
	t.Cleanup(func() { stdinIsTerminal = old })
}

func TestInitDoesNotConstructRuntime(t *testing.T) {
	projectRoot := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Chdir(projectRoot)
	withTerminalStdin(t, true)
	oldRuntime := newRuntime
	runtimeCalled := false
	newRuntime = func() runtime.Runtime {
		runtimeCalled = true
		return runtime.NewMock()
	}
	t.Cleanup(func() { newRuntime = oldRuntime })

	cmd := root()
	cmd.SetIn(strings.NewReader("\n"))
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"init"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if runtimeCalled {
		t.Fatal("init constructed the container runtime")
	}
}

func TestInitRejectsNonTTYWithoutWriting(t *testing.T) {
	projectRoot := t.TempDir()
	t.Chdir(projectRoot)
	withTerminalStdin(t, false)
	cmd := root()
	cmd.SetIn(strings.NewReader("y\n"))
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"init"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "terminal") || !strings.Contains(err.Error(), "[[volume]]") {
		t.Fatalf("non-TTY error = %v", err)
	}
	if _, err := os.Lstat(filepath.Join(projectRoot, ".coop.toml")); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("non-TTY init wrote config: %v", err)
	}
}

func TestInitUsesResolvedProjectRoot(t *testing.T) {
	projectRoot := t.TempDir()
	if err := os.WriteFile(filepath.Join(projectRoot, ".coop.toml"), nil, 0o600); err != nil {
		t.Fatal(err)
	}
	nested := filepath.Join(projectRoot, "apps", "web")
	if err := os.MkdirAll(nested, 0o755); err != nil {
		t.Fatal(err)
	}
	t.Chdir(nested)
	withTerminalStdin(t, true)
	oldRun := runProjectInit
	var gotRoot string
	runProjectInit = func(root string, _ io.Reader, _ io.Writer) error {
		gotRoot = root
		return nil
	}
	t.Cleanup(func() { runProjectInit = oldRun })

	cmd := root()
	cmd.SetIn(strings.NewReader(""))
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"init"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	wantRoot, err := filepath.EvalSymlinks(projectRoot)
	if err != nil {
		t.Fatal(err)
	}
	if gotRoot != wantRoot {
		t.Fatalf("init root = %q, want resolved marker %q", gotRoot, wantRoot)
	}
}

func TestInitRejectsCredentialsFlag(t *testing.T) {
	t.Chdir(t.TempDir())
	withTerminalStdin(t, true)
	cmd := root()
	cmd.SetIn(strings.NewReader(""))
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"--credentials", "token", "init"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "only valid when entering") {
		t.Fatalf("credential flag error = %v", err)
	}
}

func TestEntryOffersFirstBuildAndContinues(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	withTerminalStdin(t, true)
	withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func(args []string, _, _ io.Writer) error {
		m.Images = map[string]bool{args[2]: true}
		return nil
	}
	t.Cleanup(func() { buildImage = oldBuild })
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetIn(strings.NewReader("\n"))
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !entered {
		t.Fatal("entry did not continue into the session after first build")
	}
	for _, want := range []string{
		"first build takes a few minutes",
		"Sandbox image built. Helpful commands:",
		"coop tui",
		"coop doctor",
	} {
		if !strings.Contains(output.String(), want) {
			t.Fatalf("output missing %q:\n%s", want, output.String())
		}
	}
}

func TestEntryDeclinedFirstBuildFailsWithRebuildGuidance(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	withTerminalStdin(t, true)
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetIn(strings.NewReader("n\n"))
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "coop rebuild") {
		t.Fatalf("declined build error = %v, want coop rebuild guidance", err)
	}
	if entered {
		t.Fatal("declined build must not enter the session")
	}
}

func TestEntryNonInteractiveSkipsFirstBuildPrompt(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	withTerminalStdin(t, false)
	oldSession := runSession
	runSession = func(*session.Session, string, []string, []string) error { return nil }
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("non-interactive entry must not prompt:\n%s", output.String())
	}
}

func TestEntrySkipsPromptWhenImagePresent(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir()) // force the embedded core lock so the image name is deterministic
	withTerminalStdin(t, true)
	cfg, err := config.Load(".")
	if err != nil {
		t.Fatal(err)
	}
	m.Images = map[string]bool{session.EffectiveImageNameWithCoreLock(cfg, image.EmbeddedCoreLock()): true}
	oldSession := runSession
	runSession = func(*session.Session, string, []string, []string) error { return nil }
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("present image must not prompt:\n%s", output.String())
	}
}

func TestUpDeclinedFirstBuildCreatesNothing(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	emptyProject(t)
	withTerminalStdin(t, true)

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetIn(strings.NewReader("n\n"))
	cmd.SetArgs([]string{"up"})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "coop rebuild") {
		t.Fatalf("up declined build error = %v, want coop rebuild guidance", err)
	}
	if len(m.Run_) != 0 {
		t.Fatalf("declined build must not create a container: %v", m.Run_)
	}
}

func TestTUIEntryOffersFirstBuild(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	withTerminalStdin(t, true)
	withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func(args []string, _, _ io.Writer) error {
		m.Images = map[string]bool{args[2]: true}
		return nil
	}
	t.Cleanup(func() { buildImage = oldBuild })
	oldTUI, oldSession := runTUI, runSession
	runTUI = func(runtime.Runtime, []string, string) (tui.Result, error) {
		return tui.Result{EnterWorkdir: project}, nil
	}
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() {
		runTUI = oldTUI
		runSession = oldSession
	})

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetIn(strings.NewReader("\n"))
	cmd.SetArgs([]string{"tui"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !entered {
		t.Fatal("TUI entry did not continue after first build")
	}
	if !strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("TUI entry missing first-build prompt:\n%s", output.String())
	}
}

func TestRebuildUnknownBuilderStateSkipsStop(t *testing.T) {
	m := runtime.NewMock()
	m.StateErr = errors.New("runtime flaked")
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	stops := withStopBuilderHook(t, nil)
	oldBuild := buildImage
	buildImage = func([]string, io.Writer, io.Writer) error { return nil }
	t.Cleanup(func() { buildImage = oldBuild })

	var errOut bytes.Buffer
	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(&errOut)
	cmd.SetArgs([]string{"rebuild"})
	if err := cmd.Execute(); err != nil {
		t.Fatalf("unknown builder state must not fail rebuild: %v", err)
	}
	if *stops != 0 {
		t.Fatalf("builder stops = %d, want 0 (state unknown — never stop a builder we may not own)", *stops)
	}
	if !strings.Contains(errOut.String(), "builder state unknown") {
		t.Fatalf("missing unknown-state warning:\n%s", errOut.String())
	}
}

func TestEntryPromptEOFDeclines(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	withTerminalStdin(t, true)
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetIn(strings.NewReader(""))
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "coop rebuild") {
		t.Fatalf("EOF at prompt error = %v, want coop rebuild guidance", err)
	}
	if entered {
		t.Fatal("EOF at prompt must not start a build or enter the session")
	}
}

// faultyReader yields partial input and then a non-EOF error, like a
// terminal that disappears mid-read.
type faultyReader struct{ read bool }

func (r *faultyReader) Read(p []byte) (int, error) {
	if r.read {
		return 0, errors.New("tty gone")
	}
	r.read = true
	return copy(p, "y"), errors.New("tty gone")
}

func TestEntryPromptReadFailureRejectsPartialConsent(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	emptyProject(t)
	withTerminalStdin(t, true)
	oldBuild := buildImage
	built := false
	buildImage = func([]string, io.Writer, io.Writer) error {
		built = true
		return nil
	}
	t.Cleanup(func() { buildImage = oldBuild })
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetIn(&faultyReader{})
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	if err == nil || !strings.Contains(err.Error(), "read first-build prompt response") {
		t.Fatalf("read failure error = %v, want wrapped read error", err)
	}
	if built || entered {
		t.Fatalf("read failure consented anyway: built=%t entered=%t", built, entered)
	}
}

func TestEntryCurrentContainerWithoutImageTagSkipsPrompt(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	withTerminalStdin(t, true)
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	// A current container whose image tag was deleted from the store:
	// spec and image labels match, only the tag is gone. Entry must
	// reuse it without prompting for a build.
	s0, err := session.New(m, cwd)
	if err != nil {
		t.Fatal(err)
	}
	m.Existing[s0.Name] = true
	m.Started = append(m.Started, s0.Name)
	m.ContainerImages = map[string]string{s0.Name: s0.DesiredImageName()}
	m.ContainerLabels = map[string]map[string]string{s0.Name: {session.SpecLabel: s0.SpecFingerprint()}}
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !entered {
		t.Fatal("current container must be entered without a build prompt")
	}
	if strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("current container prompted for a build:\n%s", output.String())
	}
}

func TestEntryStaleContainerKeepsExplicitRebuildWorkflow(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	emptyProject(t)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	withTerminalStdin(t, true)
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	// A stale container (spec mismatch, e.g. after tool changes) with the
	// replacement image missing: recreation discards rootfs state, so it
	// must stay behind the explicit `coop rebuild` step, never the
	// default-yes first-build prompt.
	s0, err := session.New(m, cwd)
	if err != nil {
		t.Fatal(err)
	}
	m.Existing[s0.Name] = true
	m.Started = append(m.Started, s0.Name)
	m.ContainerImages = map[string]string{s0.Name: "coop:local-oldcfg"}
	m.ContainerLabels = map[string]map[string]string{s0.Name: {session.SpecLabel: "stale"}}
	oldSession := runSession
	runSession = func(*session.Session, string, []string, []string) error { return nil }
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("stale container got the first-build prompt:\n%s", output.String())
	}
}

func TestEntryPreflightFailureDefersToSession(t *testing.T) {
	m := runtime.NewMock()
	m.StateErr = errors.New("runtime flaked")
	withRuntime(t, m)
	emptyProject(t)
	withTerminalStdin(t, true)
	oldSession := runSession
	entered := false
	runSession = func(*session.Session, string, []string, []string) error {
		entered = true
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !entered {
		t.Fatal("preflight failure must defer to the session, not block entry")
	}
	if strings.Contains(output.String(), "Build it now?") {
		t.Fatalf("preflight failure prompted anyway:\n%s", output.String())
	}
}

func TestEntryFirstBuildAdoptsResolvedReleaseTools(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	xdg := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdg)
	t.Setenv("XDG_STATE_HOME", t.TempDir())
	if err := os.MkdirAll(filepath.Join(xdg, "coop"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(xdg, "coop", "coop.toml"), []byte(`
[[tools.github_release]]
name = "kata"
repo = "kenn-io/kata"
tag = "latest"
asset = "kata_{version}_linux_arm64.tar.gz"
binary = "kata"
`), 0o644); err != nil {
		t.Fatal(err)
	}
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	withTerminalStdin(t, true)
	withStopBuilderHook(t, nil)
	cached := filepath.Join(t.TempDir(), "kata")
	if err := os.WriteFile(cached, []byte("verified-kata"), 0o755); err != nil {
		t.Fatal(err)
	}
	oldResolve := resolveReleaseTools
	resolveReleaseTools = func(context.Context, []config.GitHubReleaseTool) ([]config.ResolvedReleaseTool, error) {
		return []config.ResolvedReleaseTool{{
			Name: "kata", Repo: "kenn-io/kata", RequestedTag: "latest", Tag: "v0.10.0",
			Asset: "kata_0.10.0_linux_arm64.tar.gz", Digest: "sha256:" + strings.Repeat("a", 64),
			Binary: "kata", CachePath: cached,
		}}, nil
	}
	t.Cleanup(func() { resolveReleaseTools = oldResolve })
	oldBuild := buildImage
	buildImage = func(args []string, _, _ io.Writer) error {
		m.Images = map[string]bool{args[2]: true}
		return nil
	}
	t.Cleanup(func() { buildImage = oldBuild })
	oldSession := runSession
	entered := false
	var entryImageErr error
	runSession = func(s *session.Session, _ string, _, _ []string) error {
		entered = true
		// The build tagged an image that embeds the resolved release
		// tools; the continuing session must want that same image.
		entryImageErr = s.EnsureImage()
		return nil
	}
	t.Cleanup(func() { runSession = oldSession })

	var output bytes.Buffer
	cmd := root()
	cmd.SetOut(&output)
	cmd.SetErr(&output)
	cmd.SetIn(strings.NewReader("\n"))
	cmd.SetArgs([]string{})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !entered {
		t.Fatal("entry did not continue into the session after first build")
	}
	if entryImageErr != nil {
		t.Fatalf("session desired image missing after first build: %v", entryImageErr)
	}
}

func withRuntime(t *testing.T, rt runtime.Runtime) {
	t.Helper()
	oldRuntime, oldLookPath := newRuntime, lookPath
	newRuntime = func() runtime.Runtime { return rt }
	lookPath = func(string) (string, error) { return "/bin/container", nil }
	t.Cleanup(func() {
		newRuntime = oldRuntime
		lookPath = oldLookPath
	})
}

func TestCredentialsFlagAcceptsCommaAndRepeat(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	old := runSession
	var got []string
	runSession = func(_ *session.Session, _ string, _ []string, credentials []string) error {
		got = slices.Clone(credentials)
		return nil
	}
	t.Cleanup(func() { runSession = old })

	cmd := root()
	cmd.SetArgs([]string{"--credentials", "aws-dev, github", "--credentials", "kubernetes"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	want := []string{"aws-dev", "github", "kubernetes"}
	if !slices.Equal(got, want) {
		t.Fatalf("credentials = %v, want %v", got, want)
	}
}

func TestCredentialsFlagRejectsExplicitEmptyValue(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)

	cmd := root()
	cmd.SetArgs([]string{"--credentials="})
	if err := cmd.Execute(); err == nil || !strings.Contains(err.Error(), "empty grant name") {
		t.Fatalf("error = %v, want empty grant name rejection", err)
	}
}

func TestCredentialsAfterAgentRemainGuestArgv(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	old := runSession
	var gotArgv, gotCredentials []string
	runSession = func(_ *session.Session, _ string, argv, credentials []string) error {
		gotArgv = slices.Clone(argv)
		gotCredentials = slices.Clone(credentials)
		return nil
	}
	t.Cleanup(func() { runSession = old })

	cmd := root()
	cmd.SetArgs([]string{"agent", "--credentials", "aws-dev"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !slices.Equal(gotArgv, []string{"agent", "--credentials", "aws-dev"}) || len(gotCredentials) != 0 {
		t.Fatalf("argv=%v credentials=%v", gotArgv, gotCredentials)
	}
}

func TestCredentialsFlagPropagatesThroughTUIEntry(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	oldTUI, oldSession := runTUI, runSession
	runTUI = func(_ runtime.Runtime, credentials []string, masterConfig string) (tui.Result, error) {
		if masterConfig != "/private/tui-master.toml" {
			t.Fatalf("launcher master config = %q", masterConfig)
		}
		if !slices.Equal(credentials, []string{"aws-dev", "github"}) {
			t.Fatalf("launcher credentials = %v", credentials)
		}
		return tui.Result{EnterWorkdir: project}, nil
	}
	var got []string
	runSession = func(_ *session.Session, _ string, _ []string, credentials []string) error {
		got = slices.Clone(credentials)
		return nil
	}
	t.Cleanup(func() {
		runTUI = oldTUI
		runSession = oldSession
	})

	cmd := root()
	cmd.SetArgs([]string{"--credentials", "aws-dev,github", "--master-config", "/private/tui-master.toml", "tui"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !slices.Equal(got, []string{"aws-dev", "github"}) {
		t.Fatalf("TUI credentials = %v", got)
	}
}

func TestTUIEntryEmitsConfigWarnings(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	configureMalformedReleaseToolWarning(t)
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}

	oldTUI, oldSession, oldWarnings := runTUI, runSession, warningOutput
	runTUI = func(runtime.Runtime, []string, string) (tui.Result, error) {
		return tui.Result{EnterWorkdir: project}, nil
	}
	runSession = func(*session.Session, string, []string, []string) error { return nil }
	var warnings bytes.Buffer
	warningOutput = &warnings
	t.Cleanup(func() {
		runTUI = oldTUI
		runSession = oldSession
		warningOutput = oldWarnings
	})

	cmd := root()
	cmd.SetArgs([]string{"tui"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if got := strings.Count(warnings.String(), "invalid GitHub release tool state ignored"); got != 1 {
		t.Fatalf("TUI configuration warning count = %d:\n%s", got, warnings.String())
	}
}

func TestCredentialsFlagRejectedByNonEntryCommands(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	project := t.TempDir()
	if err := os.WriteFile(filepath.Join(project, ".coop.toml"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(project)
	for _, subcommand := range []string{"up", "down", "status", "ls", "doctor", "rebuild", "upgrade", "destroy"} {
		t.Run(subcommand, func(t *testing.T) {
			cmd := root()
			cmd.SetArgs([]string{"--credentials", "token", subcommand})
			if err := cmd.Execute(); err == nil {
				t.Fatal("credential flag accepted by non-entry command")
			}
		})
	}
}

func withUpgradeCore(t *testing.T, upgrade func(context.Context, io.Writer, io.Writer) (core.UpgradeResult, error)) {
	t.Helper()
	old := upgradeCore
	upgradeCore = upgrade
	t.Cleanup(func() { upgradeCore = old })
}

func changedCoreVersion(t *testing.T, data []byte, installID, version string) []byte {
	t.Helper()
	var lock map[string]any
	if err := json.Unmarshal(data, &lock); err != nil {
		t.Fatal(err)
	}
	for _, value := range lock["packages"].([]any) {
		pkg := value.(map[string]any)
		if pkg["install_id"] == installID {
			pkg["version"] = version
			pkg["rev"] = "changed-" + version
			out, err := json.MarshalIndent(lock, "", "  ")
			if err != nil {
				t.Fatal(err)
			}
			return append(out, '\n')
		}
	}
	t.Fatalf("package %q not found", installID)
	return nil
}

func mustLoadCore(t *testing.T, stateDir string) []byte {
	t.Helper()
	lock, warning, err := core.Load(stateDir)
	if err != nil {
		t.Fatal(err)
	}
	if warning != "" {
		t.Fatalf("warning = %s", warning)
	}
	return lock
}

func TestEmptyCredentialsFlagRejectedByNonEntryCommand(t *testing.T) {
	cmd := root()
	cmd.SetArgs([]string{"--credentials=", "up"})
	if err := cmd.Execute(); err == nil || !strings.Contains(err.Error(), "only valid when entering") {
		t.Fatalf("error = %v, want non-entry command rejection", err)
	}
}

func TestRootSilencesCobraErrorAndUsageOutput(t *testing.T) {
	cmd := root()
	if !cmd.SilenceErrors || !cmd.SilenceUsage {
		t.Fatalf("root must leave error rendering to main: errors=%v usage=%v", cmd.SilenceErrors, cmd.SilenceUsage)
	}
}

func TestRootHelpDescribesProjectFloxAsOptional(t *testing.T) {
	help := root().Long
	if !strings.Contains(help, "optional project flox") {
		t.Fatalf("root help does not describe project flox as optional:\n%s", help)
	}
}

func TestResolvedVersionHonorsReleaseOverride(t *testing.T) {
	old := version
	version = "v0.1.0-beta.1"
	t.Cleanup(func() { version = old })
	if got := resolvedVersion(); got != version {
		t.Fatalf("resolvedVersion() = %q, want %q", got, version)
	}
}

func TestListDoesNotLoadCurrentProject(t *testing.T) {
	withRuntime(t, runtime.NewMock())
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, ".coop.toml"), []byte("not valid toml ="), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(dir)
	cmd := root()
	cmd.SetArgs([]string{"ls"})
	if err := cmd.Execute(); err != nil {
		t.Fatalf("ls depended on current project config/root: %v", err)
	}
}

func TestDoctorLoadsGlobalConfigFromHome(t *testing.T) {
	m := runtime.NewMock()
	m.Images = map[string]bool{session.EffectiveImageName(config.Default()): true}
	withRuntime(t, m)
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	if err := os.WriteFile(filepath.Join(home, ".coop.toml"), []byte("not valid toml ="), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Chdir(home)
	cmd := root()
	cmd.SetArgs([]string{"doctor"})
	if err := cmd.Execute(); err != nil {
		if errors.Is(err, os.ErrNotExist) {
			t.Fatal(err)
		}
		t.Fatalf("doctor depended on current project config/root: %v", err)
	}
}

func TestDoctorUsesLockedGitHubReleaseToolImageIdentity(t *testing.T) {
	m := runtime.NewMock()
	withRuntime(t, m)
	xdgConfig := t.TempDir()
	xdgState := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", xdgConfig)
	t.Setenv("XDG_STATE_HOME", xdgState)
	t.Setenv("XDG_CACHE_HOME", t.TempDir())
	global := filepath.Join(xdgConfig, "coop", "coop.toml")
	if err := os.MkdirAll(filepath.Dir(global), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(global, []byte(`
[[tools.github_release]]
name = "kata"
repo = "kenn-io/kata"
tag = "latest"
asset = "kata_{version}_linux_arm64.tar.gz"
binary = "kata"
`), 0o644); err != nil {
		t.Fatal(err)
	}
	cfg, err := config.Load("")
	if err != nil {
		t.Fatal(err)
	}
	resolved := []config.ResolvedReleaseTool{{
		Name: "kata", Repo: "kenn-io/kata", RequestedTag: "latest", Tag: "v0.12.1",
		Asset:  "kata_0.12.1_linux_arm64.tar.gz",
		Digest: "sha256:" + strings.Repeat("a", 64), Binary: "kata",
	}}
	if err := releasetool.SaveLock(filepath.Join(xdgState, "coop"), "", cfg.Tools.GitHubReleases, resolved); err != nil {
		t.Fatal(err)
	}
	cfg.Tools.ResolvedReleases = resolved
	m.Images = map[string]bool{session.EffectiveImageName(cfg): true}

	cmd := root()
	cmd.SetOut(io.Discard)
	cmd.SetErr(io.Discard)
	cmd.SetArgs([]string{"doctor"})
	if err := cmd.Execute(); err != nil {
		t.Fatalf("doctor ignored matching release-tool lock: %v", err)
	}
}
